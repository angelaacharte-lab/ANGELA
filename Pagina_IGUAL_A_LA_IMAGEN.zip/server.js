// Servidor local para probar la página con Node.js.
// Para GitHub Pages solo necesitas index.html y style.css.
const http = require('http');
const fs = require('fs');
const path = require('path');
const port = process.env.PORT || 3000;
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8'};
http.createServer((req,res)=>{
  const requested = decodeURIComponent(req.url.split('?')[0]);
  const name = requested === '/' ? 'index.html' : requested.replace(/^\/+/, '');
  const file = path.resolve(__dirname,name);
  if(!file.startsWith(path.resolve(__dirname)+path.sep)){res.writeHead(403);return res.end('Acceso denegado');}
  fs.readFile(file,(err,data)=>{
    if(err){res.writeHead(404);return res.end('Archivo no encontrado');}
    res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream'});
    res.end(data);
  });
}).listen(port,()=>console.log(`Página disponible en http://localhost:${port}`));
